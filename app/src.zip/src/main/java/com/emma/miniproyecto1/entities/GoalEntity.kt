package com.emma.miniproyecto1.entities

enum class GoalClassification {
    SHORT_TERM,
    MEDIUM_TERM,
    LONG_TERM
}

data class GoalEntity(
    val id: Int,
    val name: String,
    val description: String,
    val imageUri: String? = "", // Valor predeterminado como cadena vacía si no hay imagen
    val classification: GoalClassification // Clasificación de la meta
)
