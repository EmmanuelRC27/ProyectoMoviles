package com.emma.miniproyecto1.Model

import com.emma.miniproyecto1.entities.GoalEntity

object GoalRepository {
    private val goals = mutableListOf<GoalEntity>()

    // Método para insertar una nueva meta
    fun insertGoal(goal: GoalEntity) {
        val newGoal = goal.copy(id = goals.size + 1) // Generar un ID único
        goals.add(newGoal)
    }

    // Método para obtener todas las metas
    fun getGoals(): List<GoalEntity> {
        return goals
    }

    // Método para obtener una meta por ID
    public fun getGoalById(id: Int): GoalEntity? {
        return goals.find { it.id == id }
    }

    // Método para actualizar una meta
    fun updateGoal(updatedGoal: GoalEntity) {
        val index = goals.indexOfFirst { it.id == updatedGoal.id }
        if (index != -1) {
            goals[index] = updatedGoal
        }
    }

    // Método para eliminar una meta
    fun deleteGoal(goal: GoalEntity) {
        goals.removeIf { it.id == goal.id }
    }
}
