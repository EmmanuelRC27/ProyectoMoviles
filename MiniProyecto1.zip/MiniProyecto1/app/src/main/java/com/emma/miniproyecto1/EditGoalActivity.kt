package com.emma.miniproyecto1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class EditGoalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edit_goal_activity) // Asegúrate de que este sea el nombre correcto del layout
    }
}
